# CA-NI-FPPCT

This is a novel encryption scheme named CA-NI-FPPCT, which outperforms the FEPPCT encryption scheme. 

If you are using old Java APIs, please visit [https://github.com/BatchClayderman/II-FPPCT](https://github.com/BatchClayderman/II-FPPCT). 
